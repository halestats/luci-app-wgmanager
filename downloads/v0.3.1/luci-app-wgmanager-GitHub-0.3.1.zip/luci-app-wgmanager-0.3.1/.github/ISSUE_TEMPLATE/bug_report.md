---
name: 问题反馈
about: 报告安装、界面或客户端管理问题
title: ""
labels: ""
assignees: ""
---

## 环境

- 插件版本：
- 固件版本 / 架构：
- 符合 README 的固定接口/端口/网段条件：是 / 否

## 问题与复现步骤

1. 
2. 

## 预期结果与实际结果


## 脱敏后的诊断

请只贴 `wgmanager doctor` 的必要输出；截图先隐藏公网地址和个人信息。

**不要提交私钥、PSK、二维码、完整客户端配置、原始 wg dump、state.json、network 原文件或接管备份。**
